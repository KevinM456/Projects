from flask_sqlalchemy import SQLAlchemy
#Initlaize the Flask-SQLAlchemy instance

db = SQLAlchemy()