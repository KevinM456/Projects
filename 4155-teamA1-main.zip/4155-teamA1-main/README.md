# 4155-teamA1 - In The Loop
In order to run the web application, clone the repository to a directory on your machine.
To be able to connect to the web application, the following must be done in the IDE of your choice. 
1. Install the dependencies with npm install
2. Start the server with the command "node app"

The url to access the web application will be http://localhost:8080
