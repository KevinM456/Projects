let user = 'intheloop.system@zohomail.com';
let pass = 'Mansae_2023!';
let dbPass = encodeURIComponent("cwWBPf8c3ypio768");

module.exports = { user, pass, dbPass };