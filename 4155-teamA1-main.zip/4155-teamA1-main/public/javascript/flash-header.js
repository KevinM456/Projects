setTimeout(()=> {
    const errorHeader = document.getElementById("errorHeader");

    errorHeader.style.display = 'none';
}, 2000);