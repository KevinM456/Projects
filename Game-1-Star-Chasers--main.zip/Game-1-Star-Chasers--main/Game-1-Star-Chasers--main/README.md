# Game-1-Star-Chasers-
This is the repository for game 1

Game Title: Star Chasers

By: Nick Battista, Kevin Mai, Wilman Vasquez, William Hemric

Controls: Arrow Keys - Movement, Spacebar - Shoot

Cheat Codes:
	Alt + G: restart the game
	Alt + A: add 10 lives to player
	Alt + I: get rid of enemies and add three stars
	Alt + W: go to win screen
	Alt + L: go to lose screen